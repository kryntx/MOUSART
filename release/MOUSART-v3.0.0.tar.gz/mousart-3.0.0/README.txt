MOUSART v3.0.0 - Full-featured Serial Port Debugging Tool

Installation:
  pip3 install PyQt6 pyserial
  
Run:
  python3 -m mousart

Homepage: https://github.com/kryntx/MOUSART
